#!/bin/sh
./hw3_parser.py $@